'use strict';

const AWS = require('aws-sdk'); // eslint-disable-line import/no-extraneous-dependencies

const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.get = (event, context, callback) => {
  const params = {
    TableName: "BankAccounts",
    
  FilterExpression: "Username = :username AND Password = :password",
  // Define the expression attribute value, which are substitutes for the values you want to compare.
  ExpressionAttributeValues: {
    ":username": event.pathParameters.username,
    ":password": event.pathParameters.password,
  },
  };
  console.log(params.ExpressionAttributeValues)
  dynamoDb.scan(params, function (error, result){ 
    if (error) {
      console.log("Error", error);
    } else {
      console.log("Success", result);
      result.Items.forEach(function (element, index, array) {
        console.log(
            "printing",
            element.UserId
        );
        console.log("Success in For Looop", result);
      });
      console.log("Success after For Looop", result);
      const response = {
        statusCode: 200,
        body: JSON.stringify(result.Items),
      };
      callback(null, response);
    }
  });
  



  // fetch todo from the database
  // dynamoDb.scan(params, (error, result) => {
  //   // handle potential errors
  //   if (error) {
  //     console.error(error);
  //     callback(null, {
  //       statusCode: error.statusCode || 501,
  //       headers: { 'Content-Type': 'text/plain' },
  //       body: 'Couldn\'t fetch the todo item.' + JSON.stringify(error, undefined, 2),
  //     });
  //     return;
  //   }
  //   else{
  //     console.log("UP")
  //     const response = {
  //       statusCode: 200,
  //       body: JSON.stringify(result.Item),
  //     };
  //     callback(null, response);
  //     console.log(result.Item)
  //   }
  //   // create a response
  // });
};
